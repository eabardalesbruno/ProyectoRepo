package com.proriberaapp.ribera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiberaApplicationTests {

	@Test
	void contextLoads() {
	}

}
